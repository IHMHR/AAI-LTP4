package classes;

import java.sql.ResultSet;

/**
 * @version 1.0
 * @author Igor Martinelli
 */
public class Vendedores
{
    private int codVendedor;
    private String nomeVendedor;
    private String dataCadVendedor;
    private static ResultSet retorno;

    /**
     * @return the codVendedor
     */
    public int getCodVendedor() {
        return codVendedor;
    }

    /**
     * @param codVendedor the codVendedor to set
     */
    public void setCodVendedor(int codVendedor) {
        this.codVendedor = codVendedor;
    }

    /**
     * @return the nomeVendedor
     */
    public String getNomeVendedor() {
        return nomeVendedor;
    }

    /**
     * @param nomeVendedor the nomeVendedor to set
     */
    public void setNomeVendedor(String nomeVendedor) {
        this.nomeVendedor = nomeVendedor;
    }

    /**
     * @return the dataCadVendedor
     */
    public String getDataCadVendedor() {
        return dataCadVendedor;
    }

    /**
     * @param dataCadVendedor the dataCadVendedor to set
     */
    public void setDataCadVendedor(String dataCadVendedor) {
        this.dataCadVendedor = dataCadVendedor;
    }
}
